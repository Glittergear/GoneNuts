Mod Name: Gone Nuts
Premise: A spellcaster of some interest to the disappeared in Trademeet! His friends think he was taken by the 
Cowled Wizards, but the Wizards say that they did no such thing. Can Charname get to the bottom of this mystery?

CREDITS: 
Lava Del'Vortel for all the resources
Moggadeet, for being my soundboard and helping me troubleshoot
suy and Jarno Mikkola over on the G3 discord server for helping me make the cloak

CHANGELOG
1.0 Initial Release

WALKTHROUGH
	-Go to the Council of Six building in the Government District. Talk to Tannia.
	-Agree to her quest
	-Go to Trademeet. Go to the tavern and ask the Innkeeper if he knows anything
	-Go towards the fountain and find the Strange Squirrel.
	-Talk to the squirrel. You will need one of the following to be true:
		-Cernd is in the party
		-Jaheira is in the party
		-Jan is in the party
		-You are some sort of druid, mage, or sorcerer
	-If one of the above conditions are met, the squirrel will confess to be the missing mage! He'll explain
	-Return to Tannia at the Council of Six building to complete the quest
The end!

REWARDS
	- 2,000 gold, 5k xp per party member, Amulet of 5% Magic Resistance, and Estelin's Intent (a cloak that polymorphs you into a squirrel without taking your spellcasting away!)

Goals for upcoming versions
	Add journal entries
	Force Estelin to polymorph back into being a person