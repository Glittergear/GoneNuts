Mod Name: Gone Nuts
Premise/Info: A spellcaster of some interest disappeared in Trademeet! His friends 
think he was taken by the Cowled Wizards, but the Wizards say that they did no such thing. 
Can Charname get to the bottom of this mystery?

To start the quest, go to the Council of Six building in the Government District. Talk to 
Tannia. Unlike A Fowl Wish, this mod does feature some companion interjections. Bring along Jan, 
Jaheira, and/or Cernd for the full experience (and you'll want a druid or mage in your party to 
complete the quest, regardless).

Expect maybe 30 minutes of gameplay. Any level/party is fine so long as you have a Jaheira, Cernd, 
or Jan (or are a druid or mage yourself). You'll need to get into Trademeet, so do mind the animal 
trouble at the gates.

THANKS TO
suy and Jarno Mikkola for helping me make the cloak item
jastey for helping me figure out journal entries

CHANGELONG
1.0 initial release
1.1 Journal entry update

WALKTHROUGH
	-Go to the Council of Six building and speak with Tannia. She should be there walking around
	-Go to Trademeet. Talk to the innkeeper
	-Find and talk to the Strange Squirrel
		-YOU WILL NEED EITHER JAN/JAHEIRA/CERND OR TO BE A DRUID OR MAGE YOURSELF
	-Return to Tannia, having solved the mystery!

REWARDS
Estelin's Intent (see below), Amulent of Magic Resistence 5%, 2k gold, 5k quest XP

NEW ITEMS
Estelin's Intent--a cloak that can polymorph you temporarily into a squirrel. Keeps spellcasting
enabled

INCOMPATIBILITIES
None known